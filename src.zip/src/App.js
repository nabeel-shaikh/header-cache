import React, { Component } from 'react';
import PropTypes from 'prop-types'
import Header from './components/header/Header'
import './App.css';
import {
  Route,
  Redirect,
  Switch
} from 'react-router-dom';
import HomePage from './components/home/HomePage';
import CoursesPage from './components/course/CoursesPage';
import AuthorsPage from './components/author/AuthorsPage';
import NotFound from './components/404/NotFound'
import ManageAuthorPage from './components/author/ManageAuthorPage';
import AboutPage from './components/about/AboutPage';

class App extends Component {
  render() {
    return (
      <div>
        <div className="fluid-container">
          <Header />
          <Switch>
            <Route path='/' exact name="home" component={HomePage} />
            <Route path='/about' exact name="about" component={AboutPage} />
            <Route path='/courses' name="courses" exact component={CoursesPage} />
            <Route path='/authors' name="authors" exact component={AuthorsPage} />
            <Route path='/author/new' exact name="addAuthor" component={ManageAuthorPage} />
            <Route path='/author/:author_id' name="author" component={ManageAuthorPage} />
            <Redirect from='/about*' to='/about' />
            <Route component={NotFound} />
          </Switch>
        </div>
      </div>
    );
  }
}

App.propTypes = {
  children: PropTypes.object.isRequired
}

export default App;
