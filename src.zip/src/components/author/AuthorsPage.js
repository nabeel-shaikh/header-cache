import React, { Component } from 'react';
import PropTypes from 'prop-types';
import AuthorApi from '../../api/AuthorApi';
import { Link } from 'react-router-dom';

const AuthorList = (props) => {
    return (
        <table className="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                </tr>
            </thead>
            <tbody>
                {props.authors.map((author, index) => {
                    return (
                        <tr key={index}>
                            <td><Link to={`/author/${author.id}`}>{author.id}</Link></td>
                            <td>{author.firstName} {author.lastName}</td>
                        </tr>
                    )}
                )}
            </tbody>
        </table>
    )
}

AuthorList.propTypes = {
    authors: PropTypes.array.isRequired
}

export default class AuthorsPage extends Component {
    state = {
        authors: []
    }

    componentDidMount = () => {
        this.setState({ authors: AuthorApi.getAllAuthors() })
    }

    render() {
        return (
            <div>
                <h1>Authors</h1>
                <Link to="/author/new" className="btn btn-primary">Add Author</Link>
                <AuthorList authors={this.state.authors}/>
            </div>
        )
    }
}
