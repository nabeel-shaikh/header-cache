import React, { Component } from 'react';
import AuthorApi from '../../api/AuthorApi';
import { Prompt } from 'react-router'
import Toastr from 'toastr';


function TextInput(props) {
  function wrapperClass() {
    let wc = 'form-group'
    if (props.error && props.error.length > 0) {
      wc = `${wc} has-error`;
    }
    return wc;
  }

  return (
    <div className={wrapperClass()}>
      <label htmlFor={props.name}>{props.label}</label>
      <div className="field">
        <input type="text"
          name={props.name}
          className="form-control"
          placeholder={props.placeholder}
          value={props.value}
          onChange={props.onChange}
        />
        <div className="input">{props.error}</div>
      </div>
    </div>
  )
}


function AuthorForm(props) {
  return (
    <form>
      <TextInput 
        name="firstName"
        label="First Name"
        placeholder="First Name"
        value={props.author.firstName}
        onChange={props.onChange}
        error={props.errors.firstName}
      />
      <br />

      <TextInput 
        name="lastName"
        label="Last Name"
        placeholder="Last Name"
        value={props.author.lastName}
        onChange={props.onChange}
        error={props.errors.lastName}
      />
      <br />

      <input type="submit" value="Save" className="btn btn-success" onClick={props.onSubmit}/>
    </form>
  )
}


export default class ManageAuthorPage extends Component {
  state = {
    author: {
      id: '',
      firstName: '',
      lastName: ''
    },
    errors: {},
    isBlocking: false
  }

  componentWillMount = () => {
    let authorId = this.props.match.params.author_id;
    if (authorId) {
      this.setState({
        author: AuthorApi.getAuthorById(authorId)
      })
    }
  }

  setAuthorState = (event) => {
    let field = event.target.name;
    let value = event.target.value.trim();
    let newState = Object.assign({}, this.state);
    newState.author[field] = value;
    newState.isBlocking = value.length > 0;
    this.setState(newState, () => {console.log(this.state.author)})
  }

  authorFormisValid = () => {
    let formisValid = true;

    let errors = {}

    if (this.state.author.firstName < 3) {
      errors.firstName = 'First Name should be at least 3 characters';
      formisValid = false
    }
    if (this.state.author.lastName < 3) {
      errors.lastName = 'Last Name should be at least 3 characters';
      formisValid = false
    }

    this.setState({
      errors: errors
    })
    return formisValid;
  }

  saveAuthor = (event) => {
    event.preventDefault();

    if (!this.authorFormisValid()){
      return;
    };

    console.log(this.state.author)
    AuthorApi.saveAuthor(this.state.author);
    Toastr.success('Author saved')
    this.setState({
      isBlocking: false
    }, () => this.props.history.push('/authors'))
  }

  render() {
    console.log(this.state)
    return (
      <div>
        <Prompt
          when={this.state.isBlocking} message="Are you sure?"></Prompt>
        <h1>Manage Author</h1>
        <AuthorForm 
          author={this.state.author}
          onChange={this.setAuthorState} 
          onSubmit={this.saveAuthor}
          errors={this.state.errors}
        />
      </div>
    )
  }
}
