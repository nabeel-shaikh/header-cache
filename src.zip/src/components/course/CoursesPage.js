import React, { Component } from 'react'

export default class CoursesPage extends Component {
  render() {
    return (
      <div>
        <h1>Courses</h1>
      </div>
    )
  }
}
