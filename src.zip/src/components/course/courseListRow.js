import React from 'react';
import {Link} from 'react-router-dom';


export default function courseListRow(course) {
  return (
    <tr>
      {console.log(course.course.title)}
      <td><a href={course.course.WatchHref} target="_blank" rel="noopener noreferrer">Watch</a></td>
      <td><Link to={'/course/' + course.id}>{course.course.title}</Link></td>
      <td>{course.course.authorId}</td>
      <td>{course.course.category}</td>
      <td>{course.course.Length}</td>
    </tr>
  )
}
