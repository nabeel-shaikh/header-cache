import React from 'react'
import { Link } from 'react-router-dom'


export default function NotFound() {
  return (
    <div className="container">
      <h1>Page Not found!</h1>
      <p>Whoops! Sorry, nothing to see here</p>
      <p><Link to='/'>Go Back Home!</Link></p>
    </div>
  )
}
